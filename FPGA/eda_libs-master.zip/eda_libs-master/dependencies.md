# EDA libs dependencies

* TODO: build a complete dependency tree (automagically)
* TODO: draw a UML dependecy diagram

---

## CommandLine
* Common
* RS232
* I2C

## CommandLine_test
* CommandLine

## Common
* -

## Common_test
* std.textio

## Cordic
* ieee.math_real
* Common

## Cordic_test
* Cordic

## Ethernet
* Common_test
* Memory

## Ethernet_test
* std.textio
* Common
* Ethernet

## Frequency
* -

## Frequency_test
* Frequency

## Gates
* -

## I2C
* Common
* Memory

## I2C_test
* Common
* I2C

## Memory
* std.textio
* Common

## Memory_test:
* std.textio
* Memory
* BoardTester_test

## RS232
* Common
* Memory

## RS232_test
* RS232

## Sequential
* Gates

## SPI
* Common
* Gates
* Memory
* Sequential

## SPI_test
* SPI
