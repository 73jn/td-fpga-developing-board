<h1 align="center">
  <br>
  <img src="./img/EDA_libs.gif" alt="EDA Libs Logo" width="200" height="200">
  <br>
  Hevs EDA Libraries
  <br>
</h1>

<h4 align="center">All EDA Libraries for Hevs Projects</h4>

[![pipeline status](https://gitlab.hevs.ch/course/ElN/eda_libs/badges/master/pipeline.svg)](https://gitlab.hevs.ch/course/ElN/hdl_libs/commits/master)
[![coverage report](https://gitlab.hevs.ch/course/ElN/eda_libs/badges/master/coverage.svg)](https://gitlab.hevs.ch/course/ElN/hdl_libs/commits/master)

# Table of contents
<p align="center">
  <a href="#description">Description</a> •
  <a href="#how-to-use">How To Use</a> •
  <a href="#faq">FAQ</a> •
  <a href="#credits">Credits</a> •
  <a href="#license">License</a> •
  <a href="#find-us-on">Find us on</a>
</p>

## Description
[(Back to top)](#table-of-contents)

### More information
- http://wiki.hevs.ch/uit/
- http://wiki.hevs.ch/uit/index.php5/Components
- http://wiki.hevs.ch/uit/index.php5/Components/Designs/VHDL_template

See also the [dependencies](dependencies.md)

## How To Use
[(Back to top)](#table-of-contents)

To clone and run this application, you'll need [Git](https://git-scm.com) installed on your computer.
This repo is normally used as submodule to the laboratories and projects.

To deploy necessary Libs to github:
```bash
./Scripts/deployLibs.bash -v -p synd_eln_labs -r https://github.com/hei-synd-2131-eln/eln_labs.git
./Scripts/deployLibs.bash -v -p ete_eln_labs -r https://github.com/hei-ete-8132-eln/eln_labs.git.git
./Scripts/deployLibs.bash -v -p eln_chrono -r https://github.com/hei-synd-2131-eln/eln_chrono.git
./Scripts/deployLibs.bash -v -p eln_cursor -r https://github.com/hei-synd-2131-eln/eln_cursor.git
```
<div align="center">
![eda libs deployment](img/eln_labs_deployment-staff.png)
</div>

### Clone
```bash
# Clone repo including submodules
git clone --recursive <repo_url>
```

### Pull changes repo and submodules
```bash
# Pull all changes in the repo including changes in the submodules (of given commit)
git pull --recurse-submodules
```

#### Update to latest commit
Update submodule to latest commit and update parentrepo
```bash
# Update submodule to latest commit
git submodule update --remote --merge

# Afterwared you need to commit in the parentrepo the new pointer to the new commit in the submodule
git commit -am "Update submodule to latest commit"
```

### Add submodule
Add submodule and define the master branch as the one you want to track
```bash
git submodule add -b master <repo_url> <relative/path/to/folder>

git submodule init

git submodule update
```

## Credits
[(Back to top)](#table-of-contents)

* COF
* PRC
* ZAS
* GUO

## License
[(Back to top)](#table-of-contents)

:copyright: [All rights reserved](LICENSE)

---

## Find us on
> [hevs.ch](https://www.hevs.ch) &nbsp;&middot;&nbsp;
> Facebook [@hessovalais](https://www.facebook.com/hessovalais) &nbsp;&middot;&nbsp;
> Twitter [@hessovalais](https://twitter.com/hessovalais) &nbsp;&middot;&nbsp;
> LinkedIn [HES-SO Valais-Wallis](https://www.linkedin.com/groups/104343/) &nbsp;&middot;&nbsp;
> Youtube [HES-SO Valais-Wallis](https://www.youtube.com/user/HESSOVS)