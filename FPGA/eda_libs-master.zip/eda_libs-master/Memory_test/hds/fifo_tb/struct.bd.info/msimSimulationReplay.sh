# Script to replay the last simulation run
cd $HDS_PROJECT_DIR\..\Memory_test\work
"C:/eda/mentor/questasim64_10.1b/win64/vsim" -f hds_args.tmp
